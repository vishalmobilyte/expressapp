
var mongoose = require('mongoose'); //  Include Mongoose node mofule for database operations
var nodemailer = require('nodemailer'); //  Include Mongoose node mofule for database operations
var smtpTransport = require('nodemailer-smtp-transport');
 var transporter = nodemailer.createTransport(smtpTransport({
    service: 'gmail',
    auth: {
        user: 'test.it@gmail.com', // my mail
        pass: 'XXXX'
    }
}));
    
var userModel = require('../model/testModel'); //  ==== Model of User built in Model folder

module.exports.index = function(req, res, next) {
  res.render('myview', { title: 'Espress Engine',fname: 'Vishal Jaura'});
}
// --------------------- Save User/Register user -----------------

module.exports.register = function(req, res, next) {
	console.log(req.body);
  var user = new userModel();
  
  user.name = req.body.name;
  user.age = req.body.age;
  user.nationality = req.body.nationality;
  user.save(function(err,user){ // Save in Mongoose
		if(err){
			console.log('errorr');
			}
			else{
				//console.log("Data Inserted");
				var mailOptions = {
					from: 'karansamra.it@gmail.com', // sender address
					to: 'vishaljaura183@gmail.com', // list of receivers
					subject: 'Email Node Example', // Subject line
					text: 'This is simbple testign Nodemailer' //, // plaintext body
					// html: '<b>Hello world ✔</b>' // You can choose to send an HTML body instead
				};
				/*transporter.verify(function(error, success) {
				   if (error) {
						console.log(error);
				   } else {
						console.log('Server is ready to take our messages');
				   }
				});

				transporter.sendMail(mailOptions, function(error, info){
				if(error){
					console.log(error);
					res.json({yo: 'error'});
				}else{
					console.log('Message sent: ' + info.response);
					res.json({yo: info.response});
				};
			});*/

				res.redirect('/userlisting');
				res.send(user);
				}
	  });
}
// ------------- GET EDIT VIEW ------------------------------

module.exports.useredit = function(req, res, next) {
	
	var id = req.params.id;
	console.log(id);
	userModel.findById(id,function(err,data){ // === Get Data of User By Id to edit details
		 res.render('useredit', { title: 'EDIT User',datauser: data});
			
	  });
}

// ---------------  SAVE EDIT User  -------------------------

module.exports.editsave = function(req, res, next) {
	
  var id = req.params.id;
 
  userModel.findById(id,function(err,user){
	   user.name = req.body.name;
  user.age = req.body.age;
  user.nationality = req.body.nationality;
  user.save(function(err,user){
	  if(err){
		  console.log("errror while editing user");
		  }
		  else{
			  res.redirect("/userlisting");
			  }
	  
	  });
	  });
	  
}

// -------------  User Listing -------------------------------

module.exports.userlist = function(req, res, next) {
	
 
  userModel.find({},function(err,data){
		if(err){
			console.log('errorr');
			}
			else{
				//console.log(data);
				res.render('userlisting',{'data':data} );
				}
	  });
}
 // ------------------ Delete User  ----------------------------
 
module.exports.userdelete = function(req, res, next) {
	
	var id = req.params.id;
	console.log(id);
	userModel.findById(id,function(err,data){
		data.remove(function(err,dataa){
			if(err){
				console.log("error while deleting");
				}
				else{
					console.log(dataa);
					res.redirect('/userlisting');
					}
			});
	  });
}
