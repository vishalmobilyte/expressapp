var express = require('express');
var router = express.Router();
var controll = require('../controller/layoutController');
/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

/* GET home page. */
router.get('/myview',controll.index);


/* GET home page. */
router.get('/register', function(req, res, next) {
  res.render('register', { title: 'Register' });
	});
	
/* GET home page. */
router.post('/register', controll.register);

/* GET home page. */
router.get('/userlisting', controll.userlist);

/* DELETE USER. */
router.get('/delete/:id', controll.userdelete);

/* GET EDIT USER. */
router.get('/useredit/:id', controll.useredit);

/* SAVE EDIT USER. */
router.post('/useredit/:id', controll.editsave);


module.exports = router;
